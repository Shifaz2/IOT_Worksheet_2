from microbit import *
import radio
import time

# Morse code alphabet
MORSE_ALPHABET = {
    'A': '.-', 'B': '-...', 'C': '-.-.', 'D': '-..', 'E': '.', 'F': '..-.', 
    'G': '--.', 'H': '....', 'I': '..', 'J': '.---', 'K': '-.-', 'L': '.-..',
    'M': '--', 'N': '-.', 'O': '---', 'P': '.--.', 'Q': '--.-', 'R': '.-.',
    'S': '...', 'T': '-', 'U': '..-', 'V': '...-', 'W': '.--', 'X': '-..-',
    'Y': '-.--', 'Z': '--..', ' ': ' '
}

# Inverse Morse code alphabet
INVERSE_MORSE_ALPHABET = {value: key for key, value in MORSE_ALPHABET.items()}

# Set up the radio
radio.on()
radio.config(channel=6)

# Send function
def send_message(message):
    # Send each character in the message
    for char in message:
        # Get the Morse code for the character
        morse = MORSE_ALPHABET[char.upper()]

        # Send each dot or dash in the Morse code
        for symbol in morse:
            if symbol == '.':
                # Send a short pulse
                pin0.write_digital(1)
                radio.send('1')
                sleep(0.1)
                pin0.write_digital(0)
                radio.send('0')
                sleep(0.1)
            elif symbol == '-':
                # Send a long pulse
                pin0.write_digital(1)
                radio.send('1')
                sleep(0.3)
                pin0.write_digital(0)
                radio.send('0')
                sleep(0.1)
        
        # Leave a short gap between characters
        sleep(0.2)

# Receive function
def receive_message():
    message = ''
    while True:
        # Wait for a pulse to be received
        while pin1.read_digital() == 0:
            pass
        
        # Record the start time of the pulse
        start_time = time.ticks_us()
        
        # Wait for the pulse to end
        while pin1.read_digital() == 1:
            pass
        
        # Calculate the duration of the pulse
        duration = time.ticks_diff(time.ticks_us(), start_time)
        
        # Check if the pulse was a short pulse or a long pulse
        if duration < 300:
            message += '.'
        else:
            message += '-'
        
        # Check if the message is complete
        if message[-5:] == '     ':
            # End of message reached
            message = message[:-5] + ' '
            char = INVERSE_MORSE_ALPHABET.get(message, '')
            if char == '':
                # Unknown character, so just print the Morse code
                display.scroll(message)
            else:
                # Known character, so print the character
                display.scroll(char)
            return char
        elif message[-1] == ' ':
            # End of character reached
            char = INVERSE_MORSE_ALPHABET.get(message, '')
            if char == '':
                # Unknown character, so just print the Morse code
                display.scroll(message)
            else:
                # Known character, so print the character
                display.scroll(char)
            message = ''
